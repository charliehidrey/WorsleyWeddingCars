Worsley Wedding Cars website

Updated gallery with 35 unique photos from the supplied batches.
Duplicate photos have been removed.
Offer wording updated to: "Complementary bottle of Prosecco with weddings".

Open index.html in a browser to preview the website.
